package org.example._lab3;


import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AdminController {
    public AdminController(Stage stage) {
        VBox layout = new VBox(10);
        TableView<Admin> table = AdminDAO.getAdminTable();

        TextField nameField = new TextField();
        TextField emailField = new TextField();
        PasswordField passwordField = new PasswordField();

        Button createBtn = new Button("Create");
        Button updateBtn = new Button("Update");
        Button deleteBtn = new Button("Delete");
        Button backBtn = new Button("Back");

        createBtn.setOnAction(e -> {
            AdminDAO.createAdmin(nameField.getText(), emailField.getText(), passwordField.getText());
            table.setItems(AdminDAO.getAllAdmins());
        });

        updateBtn.setOnAction(e -> {
            Admin selected = table.getSelectionModel().getSelectedItem();
            AdminDAO.updateAdmin(selected.getId(), nameField.getText(), emailField.getText());
            table.setItems(AdminDAO.getAllAdmins());
        });

        deleteBtn.setOnAction(e -> {
            AdminDAO.deleteAdmin(table.getSelectionModel().getSelectedItem().getId());
            table.setItems(AdminDAO.getAllAdmins());
        });

        backBtn.setOnAction(e -> new DashboardController(stage, "Admin"));

        layout.getChildren().addAll(table, new Label("Name"), nameField, new Label("Email"), emailField, new Label("Password"), passwordField, createBtn, updateBtn, deleteBtn, backBtn);
        stage.setScene(new Scene(layout, 500, 500));
    }
}

