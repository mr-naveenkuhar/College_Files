package org.example._lab3;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class AdminDAO {

    public static ObservableList<Admin> getAllAdmins() {
        ObservableList<Admin> list = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Admin")) {
            while (rs.next()) {
                list.add(new Admin(rs.getInt("id"), rs.getString("name"), rs.getString("email")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void createAdmin(String name, String email, String password) {
        String sql = "INSERT INTO Admin (name, email, password) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateAdmin(int id, String name, String email) {
        String sql = "UPDATE Admin SET name=?, email=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setInt(3, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteAdmin(int id) {
        String sql = "DELETE FROM Admin WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static TableView<Admin> getAdminTable() {
        TableView<Admin> table = new TableView<>();
        table.getColumns().addAll(
                column("ID", "id"),
                column("Name", "name"),
                column("Email", "email")
        );
        table.setItems(getAllAdmins());
        return table;
    }

    private static <T> javafx.scene.control.TableColumn<Admin, T> column(String title, String property) {
        TableColumn<Admin, T> col = new TableColumn<>(title);
        col.setCellValueFactory(new PropertyValueFactory<>(property));
        return col;
    }
}

