package org.example._lab3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DashboardController {
    public DashboardController(Stage stage, String username) {
        VBox layout = new VBox(10);
        Label welcome = new Label("Welcome, " + username);
        Button adminBtn = new Button("Admin");
        Button employeeBtn = new Button("Employee");
        Button logoutBtn = new Button("Logout");
        Button exitBtn = new Button("Exit");

        adminBtn.setOnAction(e -> new AdminController(stage));
        employeeBtn.setOnAction(e -> new EmployeeController(stage));
        logoutBtn.setOnAction(e -> new LoginController(stage));
        exitBtn.setOnAction(e -> stage.close());

        layout.getChildren().addAll(welcome, adminBtn, employeeBtn, logoutBtn, exitBtn);
        stage.setScene(new Scene(layout, 400, 300));
    }
}
