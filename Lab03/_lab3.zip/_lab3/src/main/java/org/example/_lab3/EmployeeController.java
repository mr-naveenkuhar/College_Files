package org.example._lab3;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class EmployeeController {
    public EmployeeController(Stage stage) {
        VBox layout = new VBox(10);
        TableView<Employee> table = EmployeeDAO.getEmployeeTable();

        TextField nameField = new TextField();
        TextField positionField = new TextField();
        TextField salaryField = new TextField();

        Button createBtn = new Button("Create");
        Button updateBtn = new Button("Update");
        Button deleteBtn = new Button("Delete");
        Button backBtn = new Button("Back");

        createBtn.setOnAction(e -> {
            EmployeeDAO.createEmployee(nameField.getText(), positionField.getText(), Double.parseDouble(salaryField.getText()));
            table.setItems(EmployeeDAO.getAllEmployees());
        });

        updateBtn.setOnAction(e -> {
            Employee selected = table.getSelectionModel().getSelectedItem();
            EmployeeDAO.updateEmployee(selected.getId(), nameField.getText(), positionField.getText(), Double.parseDouble(salaryField.getText()));
            table.setItems(EmployeeDAO.getAllEmployees());
        });

        deleteBtn.setOnAction(e -> {
            EmployeeDAO.deleteEmployee(table.getSelectionModel().getSelectedItem().getId());
            table.setItems(EmployeeDAO.getAllEmployees());
        });

        backBtn.setOnAction(e -> new DashboardController(stage, "Employee"));

        layout.getChildren().addAll(table, new Label("Name"), nameField, new Label("Position"), positionField, new Label("Salary"), salaryField, createBtn, updateBtn, deleteBtn, backBtn);
        stage.setScene(new Scene(layout, 500, 500));
    }
}
