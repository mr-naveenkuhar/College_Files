package org.example._lab3;


import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginController {
    public LoginController(Stage stage) {
        VBox layout = new VBox(10);
        TextField emailField = new TextField();
        PasswordField passwordField = new PasswordField();
        Button loginBtn = new Button("Login");

        loginBtn.setOnAction(e -> {
            if (LoginDAO.validateLogin(emailField.getText(), passwordField.getText())) {
                new DashboardController(stage, emailField.getText());
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Credentials!");
                alert.show();
            }
        });

        layout.getChildren().addAll(new Label("Email"), emailField, new Label("Password"), passwordField, loginBtn);
        stage.setScene(new Scene(layout, 400, 300));
        stage.setTitle("Login");
        stage.show();
    }
}

