package org.example._lab3;



import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class EmployeeTest {

    @Test
    public void testCalculateAnnualSalary() {
        Employee emp1 = new Employee(1, "John Doe", "Manager", 5000);
        Employee emp2 = new Employee(2, "Jane Smith", "Developer", 4000);

        assertEquals(60000, emp1.calculateAnnualSalary(), "Annual salary should be 5000 * 12");
        assertEquals(48000, emp2.calculateAnnualSalary(), "Annual salary should be 4000 * 12");
    }

    @Test
    public void testSalaryWithZero() {
        Employee emp = new Employee(3, "Bob Martin", "Intern", 0);
        assertEquals(0, emp.calculateAnnualSalary(), "Annual salary should be 0 when salary is 0");
    }

    @Test
    public void testSalaryWithNegative() {
        Employee emp = new Employee(4, "Eve Adams", "Consultant", -1000);
        assertEquals(-12000, emp.calculateAnnualSalary(), "Annual salary should be negative when salary is negative");
    }
}
