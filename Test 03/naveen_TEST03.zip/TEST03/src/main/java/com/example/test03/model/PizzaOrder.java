package com.example.test03.model;

import javafx.beans.property.*;

public class PizzaOrder {
    private final StringProperty customerName;
    private final StringProperty mobileNumber;
    private final StringProperty pizzaSize;
    private final IntegerProperty numToppings;
    private final DoubleProperty totalBill;

    public PizzaOrder(String customerName, String mobileNumber, String pizzaSize, int numToppings, double totalBill) {
        this.customerName = new SimpleStringProperty(customerName);
        this.mobileNumber = new SimpleStringProperty(mobileNumber);
        this.pizzaSize = new SimpleStringProperty(pizzaSize);
        this.numToppings = new SimpleIntegerProperty(numToppings);
        this.totalBill = new SimpleDoubleProperty(totalBill);
    }

    public String getCustomerName() {
        return customerName.get();
    }

    public StringProperty customerNameProperty() {
        return customerName;
    }

    public String getMobileNumber() {
        return mobileNumber.get();
    }

    public StringProperty mobileNumberProperty() {
        return mobileNumber;
    }

    public String getPizzaSize() {
        return pizzaSize.get();
    }

    public StringProperty pizzaSizeProperty() {
        return pizzaSize;
    }

    public int getNumToppings() {
        return numToppings.get();
    }

    public IntegerProperty numToppingsProperty() {
        return numToppings;
    }

    public double getTotalBill() {
        return totalBill.get();
    }

    public DoubleProperty totalBillProperty() {
        return totalBill;
    }

    // Setters for updating
    public void setPizzaSize(String pizzaSize) {
        this.pizzaSize.set(pizzaSize);
    }

    public void setNumToppings(int numToppings) {
        this.numToppings.set(numToppings);
    }

    public void setTotalBill(double totalBill) {
        this.totalBill.set(totalBill);
    }
}
