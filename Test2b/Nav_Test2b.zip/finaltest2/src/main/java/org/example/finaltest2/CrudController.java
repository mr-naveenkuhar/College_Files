package org.example.finaltest2;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;

public class CrudController {
    private Stage stage;
    private TableView<Record> tableView;
    private ObservableList<Record> data;

    public CrudController(Stage stage) {
        this.stage = stage;
        this.tableView = new TableView<>();
        this.data = FXCollections.observableArrayList();
    }

    public void showCrudScene() {
        TextField nameField = new TextField();
        nameField.setPromptText("Name");
        TextField categoryField = new TextField();
        categoryField.setPromptText("Category");
        TextField priceField = new TextField();
        priceField.setPromptText("Price");

        Button addButton = new Button("Add");
        Button updateButton = new Button("Update");
        Button deleteButton = new Button("Delete");
        Button refreshButton = new Button("Refresh");

        addButton.setOnAction(e -> addRecord(nameField.getText(), categoryField.getText(), priceField.getText()));
        updateButton.setOnAction(e -> updateRecord());
        deleteButton.setOnAction(e -> deleteRecord());
        refreshButton.setOnAction(e -> loadRecords());

        tableView.getColumns().addAll(createColumn("ID", "id", 50),
                createColumn("Name", "name", 150),
                createColumn("Category", "category", 150),
                createColumn("Price", "price", 100));

        VBox layout = new VBox(10, nameField, categoryField, priceField, addButton, updateButton, deleteButton, refreshButton, tableView);
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout, 500, 500);
        stage.setScene(scene);
        stage.setTitle("CRUD Operations");
        stage.show();
        loadRecords();
    }

    private TableColumn<Record, ?> createColumn(String title, String property, int width) {
        TableColumn<Record, String> column = new TableColumn<>(title);
        column.setCellValueFactory(new PropertyValueFactory<>(property));
        column.setMinWidth(width);
        return column;
    }

    private void loadRecords() {
        data.clear();
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM records")) {
            while (rs.next()) {
                data.add(new Record(rs.getInt("id"), rs.getString("name"), rs.getString("category"), rs.getDouble("price")));
            }
            tableView.setItems(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addRecord(String name, String category, String price) {
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO records (name, category, price) VALUES (?, ?, ?)")) {
            stmt.setString(1, name);
            stmt.setString(2, category);
            stmt.setDouble(3, Double.parseDouble(price));
            stmt.executeUpdate();
            loadRecords();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateRecord() {
        Record selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try (Connection conn = DatabaseUtil.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("UPDATE records SET name=?, category=?, price=? WHERE id=?")) {
                stmt.setString(1, selected.getName());
                stmt.setString(2, selected.getCategory());
                stmt.setDouble(3, selected.getPrice());
                stmt.setInt(4, selected.getId());
                stmt.executeUpdate();
                loadRecords();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void deleteRecord() {
        Record selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try (Connection conn = DatabaseUtil.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM records WHERE id=?")) {
                stmt.setInt(1, selected.getId());
                stmt.executeUpdate();
                loadRecords();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
